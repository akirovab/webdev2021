# BookStorekz by
Nurtay Nudiyev

Akirova Bayan

Bayandina Diana

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/bookstorekz-hfwhxj)
